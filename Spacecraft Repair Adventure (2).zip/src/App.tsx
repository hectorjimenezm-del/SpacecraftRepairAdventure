import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import astronaut from "./assets/astronaut.png";
import damagedShip from "./assets/ship-damaged.png";
import repairedShip from "./assets/ship-repaired.png";
import wrench from "./assets/wrench.png";

type MaterialKind = "scrap" | "asteroid" | "gem";
type Point = { x: number; y: number };
type Material = Point & { id: number; kind: MaterialKind; collected: boolean };
type Planet = Point & { name: string; className: string; size: number };

const MATERIALS: Record<MaterialKind, { label: string; value: number }> = {
  scrap: { label: "Scrap", value: 1 },
  asteroid: { label: "Asteroid", value: 2 },
  gem: { label: "Gemstone", value: 3 },
};

const INITIAL_MATERIALS: Material[] = [
  { id: 1, kind: "scrap", x: 105, y: 112, collected: false },
  { id: 2, kind: "scrap", x: -95, y: 128, collected: false },
  { id: 3, kind: "asteroid", x: 142, y: -78, collected: false },
  { id: 4, kind: "scrap", x: -146, y: -55, collected: false },
  { id: 5, kind: "gem", x: 28, y: -158, collected: false },
  { id: 6, kind: "asteroid", x: 235, y: 68, collected: false },
  { id: 7, kind: "scrap", x: -258, y: 30, collected: false },
  { id: 8, kind: "gem", x: 192, y: -194, collected: false },
  { id: 9, kind: "asteroid", x: -202, y: -214, collected: false },
  { id: 10, kind: "scrap", x: 34, y: 286, collected: false },
  { id: 11, kind: "gem", x: -320, y: 190, collected: false },
  { id: 12, kind: "asteroid", x: 348, y: 166, collected: false },
  { id: 13, kind: "scrap", x: 310, y: -280, collected: false },
  { id: 14, kind: "gem", x: -162, y: 358, collected: false },
  { id: 15, kind: "asteroid", x: -390, y: -120, collected: false },
  { id: 16, kind: "scrap", x: 430, y: -62, collected: false },
  { id: 17, kind: "gem", x: 442, y: 310, collected: false },
  { id: 18, kind: "asteroid", x: -448, y: 338, collected: false },
  { id: 19, kind: "gem", x: -520, y: -330, collected: false },
  { id: 20, kind: "scrap", x: 535, y: -355, collected: false },
  { id: 21, kind: "asteroid", x: 660, y: 110, collected: false },
  { id: 22, kind: "gem", x: -710, y: 250, collected: false },
  { id: 23, kind: "scrap", x: 790, y: -310, collected: false },
  { id: 24, kind: "asteroid", x: -820, y: -460, collected: false },
  { id: 25, kind: "gem", x: 940, y: 390, collected: false },
  { id: 26, kind: "scrap", x: -1010, y: 520, collected: false },
  { id: 27, kind: "gem", x: 1110, y: -530, collected: false },
  { id: 28, kind: "asteroid", x: -1200, y: -610, collected: false },
  { id: 29, kind: "gem", x: 1310, y: 560, collected: false },
  { id: 30, kind: "scrap", x: -1390, y: 700, collected: false },
  { id: 31, kind: "gem", x: 1500, y: -690, collected: false },
  { id: 32, kind: "asteroid", x: -1590, y: -720, collected: false },
];

const PLANETS: Planet[] = [
  { name: "MERCURY", className: "mercury", size: 46, x: 280, y: -230 },
  { name: "VENUS", className: "venus", size: 66, x: -480, y: 350 },
  { name: "EARTH", className: "earth", size: 72, x: 650, y: 420 },
  { name: "MARS", className: "mars", size: 58, x: -790, y: -410 },
  { name: "JUPITER", className: "jupiter", size: 132, x: 1010, y: -520 },
  { name: "SATURN", className: "saturn", size: 112, x: -1190, y: 590 },
  { name: "URANUS", className: "uranus", size: 86, x: 1400, y: 650 },
  { name: "NEPTUNE", className: "neptune", size: 82, x: -1610, y: -690 },
];

const UPGRADE_COSTS = [4, 8, 15, 24];
const REPAIR_COST = 120;
const REPAIR_DURATION = 12_000;

function distance(point: Point) {
  return Math.hypot(point.x, point.y);
}

function Icon({ name }: { name: "bag" | "tether" | "credits" | "help" }) {
  const paths = {
    bag: (
      <>
        <path d="M7 9V7a5 5 0 0 1 10 0v2" />
        <path d="M5 9h14l1 12H4L5 9Z" />
      </>
    ),
    tether: (
      <>
        <path d="M7 4v5a5 5 0 0 0 10 0V4" />
        <path d="M4 4h6M14 4h6M12 14v7" />
      </>
    ),
    credits: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M15.5 8.5c-.8-.7-2-1-3.3-1-1.8 0-3.2.8-3.2 2s1.3 1.8 3.2 2.2 3.3.8 3.3 2.4-1.5 2.4-3.4 2.4c-1.4 0-2.7-.4-3.6-1.2M12 5.5v13" />
      </>
    ),
    help: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M9.6 9a2.6 2.6 0 1 1 3.5 2.5c-.8.4-1.1.9-1.1 1.7M12 17h.01" />
      </>
    ),
  };
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

function App() {
  const [started, setStarted] = useState(false);
  const [won, setWon] = useState(false);
  const [repairing, setRepairing] = useState(false);
  const [repairProgress, setRepairProgress] = useState(0);
  const [position, setPosition] = useState<Point>({ x: 0, y: 118 });
  const [materials, setMaterials] = useState(INITIAL_MATERIALS);
  const [bag, setBag] = useState<MaterialKind[]>([]);
  const [credits, setCredits] = useState(0);
  const [bagLevel, setBagLevel] = useState(0);
  const [tetherLevel, setTetherLevel] = useState(0);
  const [notice, setNotice] = useState("Return to the ship to bank your haul");
  const [showHelp, setShowHelp] = useState(false);
  const keys = useRef(new Set<string>());
  const positionRef = useRef(position);
  const bagRef = useRef(bag);
  const materialsRef = useRef(materials);

  const capacity = 5 + bagLevel * 2;
  const tetherLength = 360 + tetherLevel * 360;
  const bagCost = UPGRADE_COSTS[bagLevel];
  const tetherCost = UPGRADE_COSTS[tetherLevel];
  const nearShip = distance(position) < 122;
  const camera = { x: position.x * 0.72, y: position.y * 0.72 };

  useEffect(() => {
    positionRef.current = position;
  }, [position]);
  useEffect(() => {
    bagRef.current = bag;
  }, [bag]);
  useEffect(() => {
    materialsRef.current = materials;
  }, [materials]);

  const collectNearby = useCallback(
    (nextPosition: Point) => {
      const currentBag = bagRef.current;
      if (currentBag.length >= 5 + bagLevel * 2) return;
      const found = materialsRef.current.find(
        (item) =>
          !item.collected && Math.hypot(item.x - nextPosition.x, item.y - nextPosition.y) < 42,
      );
      if (!found) return;
      const nextMaterials = materialsRef.current.map((item) =>
        item.id === found.id ? { ...item, collected: true } : item,
      );
      const nextBag = [...currentBag, found.kind];
      materialsRef.current = nextMaterials;
      bagRef.current = nextBag;
      setMaterials(nextMaterials);
      setBag(nextBag);
      setNotice(
        `${MATERIALS[found.kind].label} secured · +${MATERIALS[found.kind].value} on return`,
      );
    },
    [bagLevel],
  );

  useEffect(() => {
    if (!started || won || repairing) return;
    let frame = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min((now - last) / 16.67, 2);
      last = now;
      let dx = 0;
      let dy = 0;
      if (keys.current.has("w") || keys.current.has("arrowup")) dy -= 1;
      if (keys.current.has("s") || keys.current.has("arrowdown")) dy += 1;
      if (keys.current.has("a") || keys.current.has("arrowleft")) dx -= 1;
      if (keys.current.has("d") || keys.current.has("arrowright")) dx += 1;
      if (dx || dy) {
        const magnitude = Math.hypot(dx, dy);
        const current = positionRef.current;
        let next = {
          x: current.x + (dx / magnitude) * 3.4 * dt,
          y: current.y + (dy / magnitude) * 3.4 * dt,
        };
        const nextDistance = distance(next);
        if (nextDistance > tetherLength) {
          next = {
            x: (next.x / nextDistance) * tetherLength,
            y: (next.y / nextDistance) * tetherLength,
          };
          setNotice("Tether limit reached · upgrade it at the ship");
        }
        positionRef.current = next;
        setPosition(next);
        collectNearby(next);
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [collectNearby, repairing, started, tetherLength, won]);

  useEffect(() => {
    if (!repairing) return;
    const startedAt = performance.now();
    let frame = 0;
    const advanceRepair = (now: number) => {
      const progress = Math.min(100, ((now - startedAt) / REPAIR_DURATION) * 100);
      setRepairProgress(progress);
      if (progress >= 100) {
        setRepairing(false);
        setWon(true);
        return;
      }
      frame = requestAnimationFrame(advanceRepair);
    };
    frame = requestAnimationFrame(advanceRepair);
    return () => cancelAnimationFrame(frame);
  }, [repairing]);

  useEffect(() => {
    const onDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(key)) {
        event.preventDefault();
        keys.current.add(key);
      }
      if (key === "e") dock();
    };
    const onUp = (event: KeyboardEvent) => keys.current.delete(event.key.toLowerCase());
    window.addEventListener("keydown", onDown);
    window.addEventListener("keyup", onUp);
    return () => {
      window.removeEventListener("keydown", onDown);
      window.removeEventListener("keyup", onUp);
    };
  });

  const dock = useCallback(() => {
    if (!nearShip || bag.length === 0) return;
    const haul = bag.reduce((total, kind) => total + MATERIALS[kind].value, 0);
    setCredits((value) => value + haul);
    setBag([]);
    bagRef.current = [];
    const replenishedField = materials.map((item) => ({ ...item, collected: false }));
    setMaterials(replenishedField);
    materialsRef.current = replenishedField;
    setNotice(`Haul processed · ${haul} repair credits banked`);
  }, [bag, materials, nearShip]);

  const upgrade = (type: "bag" | "tether") => {
    const level = type === "bag" ? bagLevel : tetherLevel;
    const cost = UPGRADE_COSTS[level];
    if (cost === undefined || credits < cost) return;
    setCredits((value) => value - cost);
    if (type === "bag") setBagLevel((value) => value + 1);
    else setTetherLevel((value) => value + 1);
    setNotice(`${type === "bag" ? "Cargo bag" : "Safety tether"} upgraded`);
  };

  const reset = () => {
    setStarted(true);
    setWon(false);
    setRepairing(false);
    setRepairProgress(0);
    setPosition({ x: 0, y: 118 });
    setMaterials(INITIAL_MATERIALS);
    setBag([]);
    setCredits(0);
    setBagLevel(0);
    setTetherLevel(0);
    setNotice("Collect nearby debris, then return to the ship");
  };

  const itemCounts = useMemo(
    () =>
      bag.reduce<Record<MaterialKind, number>>(
        (counts, kind) => ({ ...counts, [kind]: counts[kind] + 1 }),
        { scrap: 0, asteroid: 0, gem: 0 },
      ),
    [bag],
  );

  const screen = (point: Point) => ({
    left: `calc(50% + ${point.x - camera.x}px)`,
    top: `calc(50% + ${point.y - camera.y}px)`,
  });
  const shipScreen = screen({ x: 0, y: 0 });
  const playerScreen = screen(position);
  const cableDx = position.x - camera.x - (0 - camera.x);
  const cableDy = position.y - camera.y - (0 - camera.y);
  const cableLength = Math.hypot(cableDx, cableDy);
  const cableAngle = (Math.atan2(cableDy, cableDx) * 180) / Math.PI;

  return (
    <main className="game-shell">
      <div className="space-dust" />
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">DR</span>
          <div>
            <strong>DRIFT//REPAIR</strong>
            <small>Emergency EVA protocol</small>
          </div>
        </div>
        <div className="credits">
          <Icon name="credits" />
          <span>REPAIR CREDITS</span>
          <strong>{credits}</strong>
        </div>
        <button className="icon-button" onClick={() => setShowHelp(true)} aria-label="How to play">
          <Icon name="help" />
        </button>
      </header>

      <section className="playfield" aria-label="Space exploration area">
        <div
          className="range-ring"
          style={{ ...shipScreen, width: tetherLength * 2, height: tetherLength * 2 }}
        />
        {PLANETS.map((planet) => (
          <div
            className={`planet ${planet.className}`}
            key={planet.name}
            style={{ ...screen(planet), width: planet.size, height: planet.size }}
          >
            <span>{planet.name}</span>
            <i />
            <i />
            <i />
          </div>
        ))}
        {materials.map(
          (item) =>
            !item.collected && (
              <div key={item.id} className={`material ${item.kind}`} style={screen(item)}>
                <span>{MATERIALS[item.kind].value}</span>
              </div>
            ),
        )}
        <div
          className="cable"
          style={{ ...shipScreen, width: cableLength, transform: `rotate(${cableAngle}deg)` }}
        />
        <div className="ship-wrap" style={shipScreen}>
          <div className="ship-glow" />
          <img
            src={won ? repairedShip : damagedShip}
            className="ship"
            alt="Damaged red spacecraft"
          />
          {nearShip && bag.length > 0 && (
            <button className="dock-prompt" onClick={dock}>
              <kbd>E</kbd> PROCESS HAUL
            </button>
          )}
        </div>
        <div className="astronaut-wrap" style={playerScreen}>
          <img src={astronaut} className="astronaut" alt="Astronaut" />
        </div>
        <div className="notice">{notice}</div>
      </section>

      <aside className="mission-panel">
        <p className="eyebrow">MISSION OBJECTIVE</p>
        <h1>Make it home.</h1>
        <p>Salvage what you can. Upgrade your reach. Repair the ship.</p>
        <div className="repair-progress">
          <div>
            <span>SHIP INTEGRITY</span>
            <strong>{Math.min(100, Math.round((credits / REPAIR_COST) * 100))}%</strong>
          </div>
          <div className="progress-track">
            <i style={{ width: `${Math.min(100, (credits / REPAIR_COST) * 100)}%` }} />
          </div>
        </div>
        <button
          className="repair-button"
          disabled={credits < REPAIR_COST || repairing || !nearShip}
          onClick={() => setRepairing(true)}
        >
          <img src={wrench} alt="" />
          <span>
            REPAIR SHIP
            <small>
              {credits < REPAIR_COST
                ? `${REPAIR_COST} CREDITS REQUIRED`
                : !nearShip
                  ? "RETURN TO SHIP"
                  : "12 SEC REPAIR SEQUENCE"}
            </small>
          </span>
        </button>
      </aside>

      <aside className="inventory-panel">
        <div className="panel-heading">
          <div>
            <Icon name="bag" />
            <span>CARGO BAG</span>
          </div>
          <strong>
            {bag.length} / {capacity}
          </strong>
        </div>
        <div className="bag-grid">
          {Array.from({ length: capacity }).map((_, index) => (
            <div className={`bag-slot ${bag[index] ?? ""}`} key={index}>
              {bag[index] && <span />}
            </div>
          ))}
        </div>
        <div className="manifest">
          {(Object.keys(MATERIALS) as MaterialKind[]).map((kind) => (
            <div key={kind}>
              <i className={kind} />
              <span>{MATERIALS[kind].label}</span>
              <b>×{itemCounts[kind]}</b>
              <small>{MATERIALS[kind].value} CR</small>
            </div>
          ))}
        </div>
        <div className="upgrade-stack">
          <button
            disabled={bagCost === undefined || credits < bagCost}
            onClick={() => upgrade("bag")}
          >
            <Icon name="bag" />
            <span>
              EXPAND BAG<small>+2 SLOTS</small>
            </span>
            <b>{bagCost === undefined ? "MAX" : `${bagCost} CR`}</b>
          </button>
          <button
            disabled={tetherCost === undefined || credits < tetherCost}
            onClick={() => upgrade("tether")}
          >
            <Icon name="tether" />
            <span>
              EXTEND TETHER<small>+360M RANGE</small>
            </span>
            <b>{tetherCost === undefined ? "MAX" : `${tetherCost} CR`}</b>
          </button>
        </div>
      </aside>

      <div className="controls">
        <span>MOVE</span>
        <kbd>W</kbd>
        <kbd>A</kbd>
        <kbd>S</kbd>
        <kbd>D</kbd>
        <i /> <span>RETURN TO SHIP TO BANK CREDITS</span>
      </div>
      <div className="mobile-pad">
        {["↑", "←", "↓", "→"].map((arrow, index) => {
          const key = ["arrowup", "arrowleft", "arrowdown", "arrowright"][index];
          return (
            <button
              key={arrow}
              onPointerDown={() => keys.current.add(key)}
              onPointerUp={() => keys.current.delete(key)}
              onPointerLeave={() => keys.current.delete(key)}
            >
              {arrow}
            </button>
          );
        })}
      </div>

      {!started && (
        <div className="modal-backdrop">
          <div className="start-card">
            <p className="eyebrow">DISTRESS SIGNAL // 08:42:16</p>
            <h2>
              Your ship is all
              <br />
              that keeps you alive.
            </h2>
            <p>
              The engines are gone, life support is failing, and salvage is drifting into the dark.
              Stay tethered. Gather materials. Get home.
            </p>
            <div className="material-key">
              <span>
                <i className="scrap" />
                SCRAP <b>1</b>
              </span>
              <span>
                <i className="asteroid" />
                ASTEROID <b>2</b>
              </span>
              <span>
                <i className="gem" />
                GEM <b>3</b>
              </span>
            </div>
            <button onClick={reset}>
              BEGIN EVA <span>→</span>
            </button>
          </div>
        </div>
      )}

      {showHelp && (
        <div className="modal-backdrop" onClick={() => setShowHelp(false)}>
          <div className="help-card" onClick={(event) => event.stopPropagation()}>
            <button className="close" onClick={() => setShowHelp(false)}>
              ×
            </button>
            <p className="eyebrow">EVA FIELD MANUAL</p>
            <h2>Salvage. Upgrade. Escape.</h2>
            <ol>
              <li>Move with WASD or arrow keys.</li>
              <li>Drift into materials to collect them.</li>
              <li>Return to the ship and press E to bank credits.</li>
              <li>Explore all eight planets and extend your tether up to 1,800 metres.</li>
              <li>Repair the ship for 120 credits and complete the launch sequence.</li>
            </ol>
          </div>
        </div>
      )}

      {repairing && (
        <div className="modal-backdrop repairing">
          <div className="repair-sequence">
            <img src={wrench} alt="" />
            <p className="eyebrow">AUTOMATED REPAIR SEQUENCE</p>
            <h2>
              {repairProgress < 25 && "Running diagnostics"}
              {repairProgress >= 25 && repairProgress < 50 && "Sealing the hull"}
              {repairProgress >= 50 && repairProgress < 75 && "Rebuilding engines"}
              {repairProgress >= 75 && "Charging launch systems"}
            </h2>
            <div className="repair-meter">
              <i style={{ width: `${repairProgress}%` }} />
            </div>
            <strong>{Math.floor(repairProgress)}%</strong>
            <div className="repair-nodes">
              {["DIAGNOSTICS", "HULL", "ENGINES", "LAUNCH"].map((stage, index) => (
                <span className={repairProgress >= index * 25 ? "active" : ""} key={stage}>
                  <b>{index + 1}</b>
                  {stage}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {won && (
        <div className="modal-backdrop win">
          <div className="start-card">
            <p className="eyebrow">SHIP INTEGRITY // 100%</p>
            <h2>
              Engines online.
              <br />
              You made it.
            </h2>
            <p>
              The hull is sealed and navigation has a lock on home. Your long drift is finally over.
            </p>
            <button onClick={reset}>
              PLAY AGAIN <span>↻</span>
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

export default App;
